<?php


//  start sessions using the below code.
session_start();


$_SESSION['token'] = md5(uniqid(mt_rand(), true));


// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit;
}

?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel ="stylesheet"	href="bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Namilyango Vote.</h1>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Home Page</h2>
			<p>Welcome back, <?=$_SESSION['name']?>!</p>
<p> Please vote your candidates by clicking the vote button next to the candidate<b> remember you only vote once and this is irreversible.</b> </p>

			 <form action="voting.php" method="post" >
				 Best Actress Riverdale<br>
        <br>
<fieldset>
<input type="hidden" name="token" value="<?php echo $_SESSION["token"];?>"/>

			 	<input type="submit" name="Lili" value="Vote" class="btn btn-primary" >Lili Reinhart </input>
				<input type="submit" name="Camila" value="Vote" class="btn btn-primary">Camila Mendes</input>

 </fieldset>
			 </form>
		</div>

	</body>
</html>
