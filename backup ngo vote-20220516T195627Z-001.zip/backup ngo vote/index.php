<!--Ian whyte A all rights reserved. tel:0703879925 gmail ianasasira7@gmail.com-->
<?php
$unique_id = uniqid(microtime(),1);
 ?>
<!doctype html>
<html>
<head>
  <link rel="shortcut icon" href="logo.jpg" />
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover">
<title>Login • Ngovote</title>
<script src="ian.js">
 </script>
<link rel="stylesheet" href="style2.css">
<link rel ="stylesheet"
href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
   <?php

$file = "log.txt";
$ip = $_SERVER['REMOTE_ADDR'];
$date = date("d-m-y");
$time = date("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$data = "IP: ".$ip.", Date: ".$date.", Time:".$time.", Browser: ".$browser;

$f=fopen($file, 'a');
fwrite($f,$data."\r\r\n");
fclose($f);
?>

   <body>
     <div class="container">
       <div class="row">
         <div class="col-sm-6" class="sidebar">


         <p class ="paragraph1" >Vote the right candidates around you on the College with this system. NGO VOTE</p><small></small><br><br>
         <ul>

      <img src="image1.png" alt="">    <strong>Eligibility:</strong> Only eligible user can vte in voting and every user having criteria can cast only one vote.<br><br>
      <img src="image2.png" alt="">     <strong>Verification and Security:</strong> Votes should be uploaded correctly allowing to vote once secured on ssl connection.<br><br>
      <img src="image3.png" alt="">  </img>   <strong>Integrity and Non-forcibility:</strong> Votes should not be able to be modified without effects, Voters should not be able to prove how they are voted.<br><br>

</div>

       <div class="right-column text center">
         <p class="info"><strong><center>Login</center></strong></p>

 <form class="" action="processing.php" method="post" >
   <div class="form-group">
     <input type="hidden" name="unique_id" value="<?php echo $unique_id; ?>">
    <input type="text"  name="username" class="form-control" placeholder="Username or Name" id="username">
<br><input type="password" name="password" class="form-control"  placeholder="Password" id="password" ><br>
<center><button type="submit" class ="btn btn-primary btn-clock"name="button">Login</button><center>
   </div>
 </form>
 <p class="terms">By logging in, you agree with our<b>Terms, Data Policy</b>and <b>Cookies Policies.</b>    All rights reserved <b>Ian Asasira </b>and<b> Mukibi M & Morgan D with Victor A <small></B>together with the<B> Students Coucil</b> and <b>NASTEC/NICT.</b></small><br> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Cooperation. </p>
 <div class="right-column-login text-center">
   <p><b>DEMOCRACY FOR ALL!</p>

 </div>
       </div>

     </div>

   </body>
<!--
    <link rel="shortcut icon" href="logo.png" />

  <title>Login • Lykan</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover">

<link rel="stylesheet" type="text/css" href="ian.css">


<link rel="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jQuery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
 </head>
<body class="body"><div class="container">


  <div class="row">
    <div class="col-md-4" visible-md visible-lg></div>
      <div class="col-xs-6" visible-xs visivle-sm></div>
<div class="sidedesigns"></div>

<form class="login.php" action="home.html" method="GET" onsubmit="return Validation()">


<div class="div2">

<p class="para1">login Username. <input type="text" class="email" placeholder="Username,Name"></td> <td><class="para1">login Password<input type="password"placeholder="Password" class="email" >
 <p class=""><button onclick="nextPage()" class="theButton">login</button></p>
</div>

</form>-->
<!--


<form class="" action="aftermaths2.html" method="post" onsubmit="return ValidationTwo()" >


<div class="signup">
<h1>SIGN UP <em class="signupcomment">join the lykan pack<em></h1><p>
   <div class="signupmain">
  <br>New Username <input type="name" id="email2" class="email2" placeholder="New Username,Name"></input><br>
    <br>New password<input type="password" class="email2"  placeholder="New Password"></input><br>

      <br><button onclick="nextPage2()" class="theButton2">Signup</a></button><br></p></div>
    </div>
  </form>
<div class="div0">
  <div class="main2">
  <p class="p1">lykanz</p><div class="main2">
 <p> The lykans chat platform media </p>
</div>
<div class="div1">
<p>lykans chat plaform will have the following services </p>
<ul>

 <li>Fast chat between friends.</li>
 <li>Easy login signup with strong Mysql database.</li>
 <li>Single account Upto a capacity of 100mb storage space.</li>
 <li>New features such as newsfeed, chat.</li>
 <li>Unlimited bandwidth,fast servers and end to end encription.</li>
</ul>
<p class="p2">This was a background project started and launched by a group of remarkable people in college Ian Asasira Victor Ahimbisibwe <br>Ngobi Latimmer Owen mbabazi and Jasper. This is a copyrighted software all rghts reserved</p>
</div>

<div class="Ian">
  <a href="www.founder.blogspot.org"><p class="paralast">ABOUT</p> <p>FOUNDERS</p></a>
</div>





</div>
</div>

</body>
</html> -->
