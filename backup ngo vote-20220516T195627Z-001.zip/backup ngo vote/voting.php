<?php

//we start a session that will be used against our token
session_start();
/**/


$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '0000';
$DATABASE_NAME = 'login';


// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
//this below is the voting code
//this generates random key for db
/*function generatekey(){
	$keylength =1;
	$string ="abcdefg";
	$randStr = substr(str_shuffle($string), 0, $keylength);

}*/
$name = "VOTED";
//checks key in db
function checkkeys ($con, $randStr){
	$sql1 = "SELECT * FROM users";
	$result = mysqli_query($con,$sql1);
	while ($row = mysqli_fetch_assoc($result)){
if ($row['keystringkey']==$randStr) {
	echo "already voted";
}
	}
}

$username =$_SESSION['name'];
$myname ="masolo adrian";
//$_POST["lili"] this is what we stop
if (isset($_POST["Lili"])) {

	 $vote_lili = "update votes set lili=lili +1";
  $sql = "UPDATE users SET keystringkey='$name' where username='$username'";
  $run_lili = mysqli_query ($con,$sql);
	$run_lili2 =mysqli_query($con ,$vote_lili);
	$combinedlili =$run_lili.$run_lili2;
	if ($combinedlili) {
		mysqli_close($con);
		header('Location: home.php');
		exit;
	}}

if (isset($_POST["Camila"])) {
  $vote_camila = "update votes set camila=camila +1";
	  $run_camila = mysqli_query ($con, $vote_camila);
  if ($run_camila) {

header('Location: home.php');
  }
}
 ?>
